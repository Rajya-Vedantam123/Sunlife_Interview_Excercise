/*
* react display data component 
*/
import { useEffect,useState } from "react";
import axios from "axios";
import { Card,  CardText, CardBody, CardGroup } from 'reactstrap';
export default function SiteStatus() {

const [getamazondata, setamazondata]=useState([])
const [getgoogledata, setgoogledata]=useState([])
const [getalldata, setalldata]=useState([])

  useEffect(()=>{

    getAmazonStatus()
    getGoogleStatus()
    getAllStatus()
  
const interval=setInterval(()=>{
        getAmazonStatus()
        getGoogleStatus()
        getAllStatus()
      },60000)
  
  
    return()=>clearInterval(interval)
  
  },[])


  const getAmazonStatus = async () => { try {

  const amazonobj = await axios.get("/v1/amazon-status")
  
  setamazondata(amazonobj.data);
  } catch (err) { console.error(err.message); } 
};

const getGoogleStatus = async () => { try {

  const googleobj = await axios.get("/v1/google-status")
  
  setgoogledata(googleobj.data);
  } catch (err) { console.error(err.message); } 
};

const getAllStatus = async () => { try {

  const allstatusobj = await axios.get("/v1/all-status")
  
  setalldata(allstatusobj.data);
  } catch (err) { console.error(err.message); } 
};


    return (
      <div style={{margin:'40px'}} >
        
    <CardGroup style={{marginLeft:'9px',display:'flex',flexFlow: 'row wrap',maxWidth: 'fit-content'}} >

    <Card  class="card border-info shadow-lg p-1 mb-6 bg-white rounded ml-0"  style={{ boxShadow: '3px 2px 10px rgba(27, 94, 62, 0.99)',
                  margin: '0em',padding: '1em',marginLeft: '0px !important' }} >
      <CardBody class="col d-flex justify-content-center">
      <h5 class="card-title">Amazon</h5>
      <CardText>url: {getamazondata.url}</CardText>
      <CardText>statuscode: {getamazondata.statusCode}</CardText>
      <CardText>duration: {getamazondata.duration}</CardText>
      <CardText>date: {getamazondata.date}</CardText>
    </CardBody>
  </Card>

  <Card  class="card border-info shadow-lg p-1 mb-6 bg-white rounded ml-0"  style={{ boxShadow: '3px 2px 10px rgba(27, 94, 62, 0.99)',
                  margin: '0em',padding: '1em',marginLeft: '0px !important' }} >
  
      <CardBody>
      <h5 class="card-title">Goolge</h5>
      <CardText>url: {getgoogledata.url}</CardText>
      <CardText>statuscode: {getgoogledata.statusCode}</CardText>
      <CardText>duration: {getgoogledata.duration}</CardText>
      <CardText>date: {getgoogledata.date}</CardText>
    </CardBody>
  </Card>
  <Card  class="card border-info shadow-lg p-1 mb-6 bg-white rounded ml-0"  style={{ width: '55rem',boxShadow: '3px 2px 10px rgba(27, 94, 62, 0.99)',
                  margin: '0em',padding: '1em',marginLeft: '0px !important' }} >
  
    <CardBody>
    <h5 class="card-title">All</h5>
    </CardBody>
  {getalldata.map(alldata => {
      return (
      <CardBody>
      <CardText>url: {alldata.url}</CardText>
      <CardText>statuscode: {alldata.statusCode}</CardText>
      <CardText>duration: {alldata.duration}</CardText>
      <CardText>date: {alldata.date}</CardText>
    </CardBody>
  
        
      );
    })}
    </Card>
  
      </CardGroup>
      </div>
    );

}
    

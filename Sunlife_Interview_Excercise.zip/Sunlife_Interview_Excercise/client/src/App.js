/*
* App.js 
* React UI main function 
*/
import React from 'react';
import './App.css';
import { Container,} from 'reactstrap';
import SiteStatus from "./components/SiteStatus";

function App() {
  return (
   <div style={{
           backgroundColor: 'black',
           justifyContent: "center",

         }}
       >

     <Container fluid>
      <h4 style={{
           color: 'white',
           maxWidth: '1800px'

         }} >Maxwell Health / Sun Life Take Home Exercise</h4>
        <SiteStatus />
    </Container>

    </div>
  );
}

export default App;

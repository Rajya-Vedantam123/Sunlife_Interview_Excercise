/*
* routehandlers.js
* /v1 routehandlers 
*/
"use strict"
const express = require("express");
const router = express.Router();
const axios = require('axios')
const https = require('https');
const async = require("async");

async function check_site(url) {
 
  let start_time = new Date().getTime();
  let responsedata = await axios.get(url);
  let jsonobj = {
    url: responsedata.config.url,
    statusCode: responsedata.status,
    duration: new Date().getTime() - start_time,
    date: Date.parse(responsedata.headers.date)/1000,
  };
  if(responsedata.status == 200){
      return jsonobj
  }else{
    const error = new Error('404: Not found');
       
    return error

  }
  
}
/* amazon-status route hanlder 
* returns output similar to 
*    {"url":"https://amazon.com","statusCode":200,"duration":639,"date":1676232064000}                 
*    
*/
router.route("/amazon-status").get((req,res) =>{
 check_site('https://amazon.com').then(data => {
    res.json(data)
   
})

})
/* google-status route hanlder 
* returns output similar to 
*    {"url":"https://google.com","statusCode":200,"duration":139,"date":1676232201000}                
*    
*/
router.route("/google-status").get(async(req,res) =>{
    check_site('https://google.com').then(data => {
      res.json(data)
    
  })
})

/* all-status route hanlder 
* returns output similar to 
*    [{"url":"https://amazon.com","statusCode":200,"duration":527,"date":1676232229000},
*     {"url":"https://google.com","statusCode":200,"duration":137,"date":1676232229000}]                    
*    
*/
router.route("/all-status").get(async(req,res) =>{
  var site_info_arr =[]
  var amazonstatus = await check_site('https://amazon.com');
  var goolestatus = await check_site('https://google.com');
  site_info_arr.push(amazonstatus)
  site_info_arr.push(goolestatus)
  res.json(site_info_arr);

})
module.exports = router;

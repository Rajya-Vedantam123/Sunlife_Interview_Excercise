/*
* server.js
* initialize and start the server listening http and https ports
*/
"use strict"
const express = require("express");
var https = require('https');
//user can reassign default http port through an environment variable called PORT
const PORT = process.env.PORT || 41390;
//user can reassign default https port through an environment variable called TLSPORT
const TLS_PORT = process.env.TLSPORT || 41391;
const path = require('path');
const app = express();
const fs = require('fs');
const selfSigned = require('openssl-self-signed-certificate');
const handlers = require("./controllers/routehandlers")

// Static Middleware
app.use(express.static(path.resolve(__dirname, '../client/build')));

/*
* Server route handler 
*/
app.use("/v1",handlers) 

/*
* Default route 
*/
app.get('/', (req, res) => {
  res.sendFile(path.resolve(__dirname, '../client/build', 'index.html'));
});


/*
 * Create and start HTTPS server.
 */

app.listen(PORT, () => {
  console.log(`HTTP Server listening on ${PORT}`);
});

//setup a handler for unknown/malformed routes
app.use('*', function (req, res) {
  res.status(404).json({ message: 'Route not handled: malformed URL or non-existing static resource' });
});


/*
* Using self-signed cert 
*/
var options = {
  key: selfSigned.key,
  cert: selfSigned.cert,

  NPNProtocols: ['http/2.0', 'spdy', 'http/1.1', 'http/1.0'],    
    ciphers: [
               "ECDHE-RSA-AES128-GCM-SHA256",
                "ECDHE-ECDSA-AES128-GCM-SHA256",
                "ECDHE-RSA-AES256-GCM-SHA384",
                "ECDHE-ECDSA-AES256-GCM-SHA384",
                "DHE-RSA-AES128-GCM-SHA256",
                "ECDHE-RSA-AES128-SHA256",
                "DHE-RSA-AES128-SHA256",
                "ECDHE-RSA-AES256-SHA384",
                "DHE-RSA-AES256-SHA384",
                "ECDHE-RSA-AES256-SHA256",
                "DHE-RSA-AES256-SHA256",
                "HIGH",
                "!aNULL",
                "!eNULL",
                "!EXPORT",
                "!DES",
                "!RC4",
                "!MD5",
                "!PSK",
                "!SRP",
                "!CAMELLIA",
                "!ECDHE-RSA-DES-CBC3-SHA",
                "!DES-CBC3-SHA"
        ].join(':'),
    honorCipherOrder: true,
   // secureOptions: minimumTLSVersion('tlsv12')

};
/*
 * Create and start HTTPS server.
 */
const server = https.createServer(options, app).listen(TLS_PORT);
console.log(`HTTPS Server listening on ${TLS_PORT}`);
server.keepAliveTimeout = 60000 * 2;